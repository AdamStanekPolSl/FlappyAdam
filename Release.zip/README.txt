	---FlappyAdam---

Before extraction FlappyAdam.exe:

1.	This app has no sign certificate, it is possible that antivirus and Windows 10 services will
	remove the game executable.

About:

1.	The game needs some files to run well. As default they are in game folder.

2. 	You can change default path by creating (or editing) localDirectory.txt with the new directory inside
	(new directory have to ends with "/").
	REMEMBER: localDirectory.txt should be in game folder.

3. 	Configuration and best score files will be created in  default directory. Move them to the new
	path, if you had been playing earlier with different path.

4.	Defaults settings:
	Resolution: 1280x720
	Full Screen: OFF
	Vertical Sync: ON

5.	The game works better in enabled Full Screen mode.
	You can change this in game or by editting config.txt.